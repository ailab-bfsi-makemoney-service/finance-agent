import json
from typing import Any, Dict

from rag.retriever_v2 import RAGRetriever
from orchestrator.intent_router import IntentRouter


class FinanceAgent:
    """
    FinanceAgent orchestrator – Option A (unified RAG retriever).

    * IntentRouter detects the intent from question text.
    * Each intent module in `intents/` exposes:
          INTENT_NAME = "overall_spend"
          KEYWORDS = [...]
          def handle(question: str, retriever: RAGRetriever) -> dict | str

    * This class normalizes handler outputs into the shape expected
      by the FastAPI /ask endpoint and the front-end UI:

          {
            "intent": str,
            "answer": str,
            "details": dict,
            "chart": dict | None,
            "data": dict
          }
    """

    def __init__(self) -> None:
        print("[INIT] FinanceAgent orchestrator (Option A: RAG-centric)")
        self.retriever = RAGRetriever()
        self.router = IntentRouter()

    # -------------------- helpers --------------------
    @staticmethod
    def _safe_load(raw: Any) -> Dict[str, Any]:
        """Accepts dict or JSON string and returns a dict safely."""
        if isinstance(raw, dict):
            return raw
        if isinstance(raw, str):
            try:
                parsed = json.loads(raw)
                if isinstance(parsed, dict):
                    return parsed
            except Exception:
                pass
        return {}

    def _fallback_summary(self, intent: str, question: str) -> Dict[str, Any]:
        """Generic RAG-based fallback if no handler or handler fails."""
        try:
            raw = self.retriever.query(question + " include all categories")
            data = self._safe_load(raw)

            total = data.get("total_spend") or data.get("total") or 0.0
            matches = data.get("matches", 0)

            answer = (
                f"I ran into a problem with the '{intent}' intent, "
                f"but here is a basic summary: you spent about "
                f"${total:,.2f} across {matches} transactions."
            )

            details = {
                "matches": matches,
                "top_merchants": data.get("top_merchants", []),
                "top_categories": data.get("top_categories", []),
                "top_cuisines": data.get("top_cuisines", []),
            }

            return {
                "intent": intent,
                "answer": answer,
                "details": details,
                "chart": None,
                "data": data,
            }
        except Exception as e:
            print("[ERROR] Fallback RAG also failed:", e)
            return {
                "intent": intent,
                "answer": "Something went wrong while answering this question.",
                "details": {},
                "chart": None,
                "data": {},
            }

    def _normalize_result(self, intent: str, raw: Any) -> Dict[str, Any]:
        """Normalize handler return into {intent, answer, details, chart, data}."""
        # Case 1: dict
        if isinstance(raw, dict):
            out_intent = raw.get("intent") or intent
            answer = raw.get("answer", "")

            data = raw.get("data")
            if data is None:
                # if handler returned only the data payload, treat it as such
                data = raw

            details = raw.get("details")
            if details is None and isinstance(data, dict):
                details = {
                    "matches": data.get("matches"),
                    "top_merchants": data.get("top_merchants"),
                    "top_categories": data.get("top_categories"),
                    "top_cuisines": data.get("top_cuisines"),
                }

            chart = raw.get("chart")

            return {
                "intent": out_intent,
                "answer": answer,
                "details": details or {},
                "chart": chart,
                "data": data or {},
            }

        # Case 2: string
        if isinstance(raw, str):
            # try to parse as JSON and recurse
            try:
                parsed = json.loads(raw)
                if isinstance(parsed, dict):
                    return self._normalize_result(intent, parsed)
            except Exception:
                pass
            # plain-text
            return {
                "intent": intent,
                "answer": raw,
                "details": {},
                "chart": None,
                "data": {},
            }

        # Case 3: anything else -> stringify
        return {
            "intent": intent,
            "answer": str(raw),
            "details": {},
            "chart": None,
            "data": {},
        }

    # -------------------- main API --------------------
    def analyze(self, question: str) -> Dict[str, Any]:
        """Main entry point used by /ask."""
        try:
            intent = self.router.detect(question)
        except Exception as e:
            print("[ERROR] Intent detection failed:", e)
            return {
                "intent": "error",
                "answer": f"Sorry, I couldn't understand the question ({e}).",
                "details": {},
                "chart": None,
                "data": {},
            }

        print(f"[ROUTER] Intent → {intent}")

        handler = None
        if hasattr(self.router, "handlers"):
            handler = self.router.handlers.get(intent) or self.router.handlers.get("fallback")

        if handler is None:
            print(f"[WARN] No handler for '{intent}', using fallback summary.")
            return self._fallback_summary(intent, question)

        try:
            # Option A: handlers take (question, retriever)
            raw = handler(question, self.retriever)
            return self._normalize_result(intent, raw)
        except Exception as e:
            print(f"[ERROR] Handler for intent '{intent}' failed:", e)
            return self._fallback_summary(intent, question)

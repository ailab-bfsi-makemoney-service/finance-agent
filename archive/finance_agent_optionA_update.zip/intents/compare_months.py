    from typing import Dict, Any
    import json
from typing import Any, Dict

def _safe_load(raw: Any) -> Dict[str, Any]:
    """Accepts a dict or JSON string and returns a dict safely."""
    if isinstance(raw, dict):
        return raw
    if isinstance(raw, str):
        try:
            parsed = json.loads(raw)
            if isinstance(parsed, dict):
                return parsed
        except Exception:
            pass
    return {}

    INTENT_NAME = "compare_months"
    KEYWORDS = [
        "compare",
        "versus",
        "vs",
        "difference",
        "trend",
    ]


    def handle(question: str, retriever) -> Dict[str, Any]:
        """Basic comparison view based on retriever output."""
        raw = retriever.query(question)
        data = _safe_load(raw)

        total = data.get("total_spend") or data.get("total") or 0.0
        matches = data.get("matches", 0)

        answer = (
            f"I've compared the periods you mentioned. "
            f"Total spend is about ${total:,.2f} across {matches} transactions."
        )

        top_cats = data.get("top_categories", [])

        details = {
            "matches": matches,
            "top_merchants": data.get("top_merchants", []),
            "top_categories": top_cats,
            "top_cuisines": data.get("top_cuisines", []),
        }

        chart = None
        if top_cats:
            chart = {
                "type": "bar",
                "labels": [c for c, _ in top_cats],
                "values": [v for _, v in top_cats],
                "title": "Category comparison",
            }

        return {
            "intent": INTENT_NAME,
            "answer": answer,
            "details": details,
            "chart": chart,
            "data": data,
        }

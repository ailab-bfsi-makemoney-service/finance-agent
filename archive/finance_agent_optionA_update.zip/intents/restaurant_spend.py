    from typing import Dict, Any
    from .utils_date import describe_period
    import json
from typing import Any, Dict

def _safe_load(raw: Any) -> Dict[str, Any]:
    """Accepts a dict or JSON string and returns a dict safely."""
    if isinstance(raw, dict):
        return raw
    if isinstance(raw, str):
        try:
            parsed = json.loads(raw)
            if isinstance(parsed, dict):
                return parsed
        except Exception:
            pass
    return {}

    INTENT_NAME = "restaurant_spend"
    KEYWORDS = [
        "restaurant",
        "restaurants",
        "dining",
        "food",
        "cuisine",
        "eat out",
    ]


    def handle(question: str, retriever) -> Dict[str, Any]:
        """Summarize restaurant spend for the requested period."""
        # Nudge retriever toward restaurant-like spend
        q2 = question + " restaurant and dining spending"
        raw = retriever.query(q2)
        data = _safe_load(raw)

        total = data.get("total_spend") or data.get("total") or 0.0
        matches = data.get("matches", 0)
        period = describe_period(question)

        answer = (
            f"You spent ${total:,.2f} at restaurants in {period}, "
            f"across {matches} transactions."
        )

        top_merchants = data.get("top_merchants", [])
        top_categories = data.get("top_categories", [])
        top_cuisines = data.get("top_cuisines", [])

        chart = None
        if top_merchants:
            chart = {
                "type": "bar",
                "labels": [m for m, _ in top_merchants],
                "values": [v for _, v in top_merchants],
                "title": "Top restaurant merchants",
            }

        details: Dict[str, Any] = {
            "matches": matches,
            "top_merchants": top_merchants,
            "top_categories": top_categories,
            "top_cuisines": top_cuisines,
        }

        return {
            "intent": INTENT_NAME,
            "answer": answer,
            "details": details,
            "chart": chart,
            "data": data,
        }

    from typing import Dict, Any
    import json
from typing import Any, Dict

def _safe_load(raw: Any) -> Dict[str, Any]:
    """Accepts a dict or JSON string and returns a dict safely."""
    if isinstance(raw, dict):
        return raw
    if isinstance(raw, str):
        try:
            parsed = json.loads(raw)
            if isinstance(parsed, dict):
                return parsed
        except Exception:
            pass
    return {}

    INTENT_NAME = "top_merchants"
    KEYWORDS = [
        "top merchants",
        "largest merchants",
        "biggest merchants",
        "where did i spend the most",
    ]


    def handle(question: str, retriever) -> Dict[str, Any]:
        """Show top merchants by spend for the period."""
        raw = retriever.query(question)
        data = _safe_load(raw)

        merchants = data.get("top_merchants", [])
        answer = "Here are your top merchants by spend for the selected period."

        details = {
            "top_merchants": merchants,
            "matches": data.get("matches", 0),
        }

        chart = None
        if merchants:
            chart = {
                "type": "bar",
                "labels": [m for m, _ in merchants],
                "values": [v for _, v in merchants],
                "title": "Top merchants",
            }

        return {
            "intent": INTENT_NAME,
            "answer": answer,
            "details": details,
            "chart": chart,
            "data": data,
        }

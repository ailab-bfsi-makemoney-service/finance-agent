    from typing import Dict, Any
    from .utils_date import describe_period
    import json
from typing import Any, Dict

def _safe_load(raw: Any) -> Dict[str, Any]:
    """Accepts a dict or JSON string and returns a dict safely."""
    if isinstance(raw, dict):
        return raw
    if isinstance(raw, str):
        try:
            parsed = json.loads(raw)
            if isinstance(parsed, dict):
                return parsed
        except Exception:
            pass
    return {}

    INTENT_NAME = "overall_spend"
    KEYWORDS = [
        "overall",
        "total spend",
        "how much did i spend",
        "all categories",
        "everything",
    ]


    def handle(question: str, retriever) -> Dict[str, Any]:
        """Overall spend across all categories for the requested period."""
        q2 = question + " include all categories"
        raw = retriever.query(q2)
        data = _safe_load(raw)

        total = data.get("total_spend") or data.get("total") or 0.0
        matches = data.get("matches", 0)
        period = describe_period(question)

        answer = (
            f"Your overall spend in {period} is ${total:,.2f}, "
            f"across {matches} transactions."
        )

        details = {
            "matches": matches,
            "top_merchants": data.get("top_merchants", []),
            "top_categories": data.get("top_categories", []),
            "top_cuisines": data.get("top_cuisines", []),
        }

        chart = None
        top_cats = data.get("top_categories", [])
        if top_cats:
            chart = {
                "type": "bar",
                "labels": [c for c, _ in top_cats],
                "values": [v for _, v in top_cats],
                "title": "Category breakdown",
            }

        return {
            "intent": INTENT_NAME,
            "answer": answer,
            "details": details,
            "chart": chart,
            "data": data,
        }

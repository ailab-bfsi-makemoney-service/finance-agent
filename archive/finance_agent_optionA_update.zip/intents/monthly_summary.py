    from typing import Dict, Any
    from .utils_date import describe_period
    import json
from typing import Any, Dict

def _safe_load(raw: Any) -> Dict[str, Any]:
    """Accepts a dict or JSON string and returns a dict safely."""
    if isinstance(raw, dict):
        return raw
    if isinstance(raw, str):
        try:
            parsed = json.loads(raw)
            if isinstance(parsed, dict):
                return parsed
        except Exception:
            pass
    return {}

    INTENT_NAME = "monthly_summary"
    KEYWORDS = [
        "summary",
        "monthly summary",
        "month summary",
        "overview",
    ]


    def handle(question: str, retriever) -> Dict[str, Any]:
        """High-level monthly summary for the requested period."""
        raw = retriever.query(question)
        data = _safe_load(raw)

        total = data.get("total_spend") or data.get("total") or 0.0
        matches = data.get("matches", 0)
        period = describe_period(question)

        answer = (
            f"Your spending summary for {period}: "
            f"${total:,.2f} across {matches} transactions."
        )

        top_cats = data.get("top_categories", [])

        details = {
            "matches": matches,
            "top_merchants": data.get("top_merchants", []),
            "top_categories": top_cats,
            "top_cuisines": data.get("top_cuisines", []),
        }

        chart = None
        if top_cats:
            chart = {
                "type": "bar",
                "labels": [c for c, _ in top_cats],
                "values": [v for _, v in top_cats],
                "title": "Top categories",
            }

        return {
            "intent": INTENT_NAME,
            "answer": answer,
            "details": details,
            "chart": chart,
            "data": data,
        }

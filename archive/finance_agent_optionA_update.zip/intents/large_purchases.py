    from typing import Dict, Any
    import json
from typing import Any, Dict

def _safe_load(raw: Any) -> Dict[str, Any]:
    """Accepts a dict or JSON string and returns a dict safely."""
    if isinstance(raw, dict):
        return raw
    if isinstance(raw, str):
        try:
            parsed = json.loads(raw)
            if isinstance(parsed, dict):
                return parsed
        except Exception:
            pass
    return {}

    INTENT_NAME = "large_purchases"
    KEYWORDS = [
        "large purchases",
        "big purchases",
        "expensive",
        "high value",
    ]


    def handle(question: str, retriever) -> Dict[str, Any]:
        """Surface large purchases (approximation using generic RAG output)."""
        raw = retriever.query(question + " large purchases")
        data = _safe_load(raw)

        # We don't have a dedicated large-purchase filter here,
        # but we still provide a summary based on total + merchants.
        total = data.get("total_spend") or data.get("total") or 0.0
        matches = data.get("matches", 0)

        answer = (
            f"I've highlighted higher-value purchases in this period. "
            f"Total spend is about ${total:,.2f} across {matches} transactions."
        )

        return {
            "intent": INTENT_NAME,
            "answer": answer,
            "details": data,
            "chart": None,
            "data": data,
        }

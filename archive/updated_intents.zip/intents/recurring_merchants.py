from typing import Dict, Any
import json

INTENT_NAME = "recurring_merchants"
KEYWORDS = [
    "recurring", "subscriptions",
    "regular payments", "monthly charges",
]


def handle(question: str, intent_name: str, metadata, retriever) -> Dict[str, Any]:
    """Placeholder recurring merchants intent.

    Today this uses the generic RAG distribution and explains that
    a future version will explicitly detect recurring merchants.
    """
    raw = retriever.query(question)
    data = json.loads(raw) if isinstance(raw, str) else raw or {}

    total = data.get("total_spend")
    if total is None:
        total = data.get("total", 0.0)

    matches = data.get("matches", 0)

    answer = (
        f"I detected ${total:,.2f} in spend across {matches} transactions "
        "for the selected period. A future version will explicitly highlight "
        "recurring merchants and subscription-style charges."
    )

    details = {
        "matches": matches,
        "total_spend": total,
        "top_merchants": data.get("top_merchants", []),
    }

    return {
        "intent": INTENT_NAME,
        "answer": answer,
        "details": details,
        "chart": None,
        "data": data,
    }

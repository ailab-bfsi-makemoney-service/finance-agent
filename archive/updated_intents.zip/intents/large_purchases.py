from typing import Dict, Any
import json

INTENT_NAME = "large_purchases"
KEYWORDS = [
    "large purchases", "big purchases",
    "over $", "greater than $", "high value",
]


def handle(question: str, intent_name: str, metadata, retriever) -> Dict[str, Any]:
    """Placeholder large purchases intent.

    For now, this just reuses the generic RAG summary and encourages
    the user to refine with an amount threshold.
    """
    raw = retriever.query(question)
    data = json.loads(raw) if isinstance(raw, str) else raw or {}

    total = data.get("total_spend")
    if total is None:
        total = data.get("total", 0.0)

    matches = data.get("matches", 0)

    answer = (
        f"I found {matches} transactions in the selected period, "
        f"with total spend ${total:,.2f}. "
        "You can refine your question (for example, 'over $200 in March 2025') "
        "for a more precise breakdown of large purchases."
    )

    details = {
        "matches": matches,
        "total_spend": total,
        "top_merchants": data.get("top_merchants", []),
    }

    return {
        "intent": INTENT_NAME,
        "answer": answer,
        "details": details,
        "chart": None,
        "data": data,
    }

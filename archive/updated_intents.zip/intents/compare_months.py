from typing import Dict, Any
import json

from .utils_date import describe_period

INTENT_NAME = "compare_months"
KEYWORDS = [
    "compare months", "month over month",
    "vs last month", "versus last month",
    "trend", "increase", "decrease",
]


def handle(question: str, intent_name: str, metadata, retriever) -> Dict[str, Any]:
    """Compare spend in a period to the previous period (rough MoM)."""
    raw_current = retriever.query(question)
    data_current = json.loads(raw_current) if isinstance(raw_current, str) else raw_current or {}

    alt_q = question + " compared to the previous month"
    raw_prev = retriever.query(alt_q)
    data_prev = json.loads(raw_prev) if isinstance(raw_prev, str) else raw_prev or {}

    total_current = data_current.get("total_spend")
    if total_current is None:
        total_current = data_current.get("total", 0.0)

    total_prev = data_prev.get("total_spend")
    if total_prev is None:
        total_prev = data_prev.get("total", 0.0)

    delta = total_current - total_prev
    if delta > 0:
        direction = "higher"
    elif delta < 0:
        direction = "lower"
    else:
        direction = "about the same"

    period_label = describe_period(question)

    answer = (
        f"In {period_label}, you spent ${total_current:,.2f}, which is "
        f"{direction} than the previous month by ${abs(delta):,.2f}."
    )

    details = {
        "total_current": total_current,
        "total_previous": total_prev,
        "delta": delta,
        "matches_current": data_current.get("matches", 0),
        "matches_previous": data_prev.get("matches", 0),
    }

    chart = {
        "type": "bar",
        "labels": ["Previous month", period_label],
        "values": [total_prev, total_current],
        "title": "Month-over-Month Spend",
    }

    return {
        "intent": INTENT_NAME,
        "answer": answer,
        "details": details,
        "chart": chart,
        "data": {"current": data_current, "previous": data_prev},
    }

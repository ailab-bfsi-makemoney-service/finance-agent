from typing import Dict, Any
import json

from .utils_date import describe_period

INTENT_NAME = "restaurant_spend"
KEYWORDS = [
    "restaurant", "restaurants", "dining", "eat out",
    "food & drink", "food and drink", "cuisine", "lunch", "dinner",
]


def handle(question: str, intent_name: str, metadata, retriever) -> Dict[str, Any]:
    """Restaurant spend intent.

    Uses retriever.query(question) and relies on the RAG pipeline to
    perform correct restaurant detection & aggregation.
    """
    raw = retriever.query(question)
    data = json.loads(raw) if isinstance(raw, str) else raw or {}

    total = data.get("total_spend")
    if total is None:
        total = data.get("total", 0.0)

    matches = data.get("matches", 0)
    period_label = describe_period(question)

    answer = (
        f"You spent ${total:,.2f} at restaurants in {period_label} "
        f"across {matches} transactions."
    )

    details = {
        "matches": matches,
        "total_spend": total,
        "top_merchants": data.get("top_merchants", []),
        "top_categories": data.get("top_categories", []),
        "top_cuisines": data.get("top_cuisines", []),
    }

    chart = None
    top_restaurants = data.get("top_merchants") or data.get("top_restaurants")
    if top_restaurants:
        chart = {
            "type": "bar",
            "labels": [name for name, _ in top_restaurants],
            "values": [amt for _, amt in top_restaurants],
            "title": "Top Restaurant Spend",
        }

    return {
        "intent": INTENT_NAME,
        "answer": answer,
        "details": details,
        "chart": chart,
        "data": data,
    }

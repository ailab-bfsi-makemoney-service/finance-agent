from typing import Dict, Any
import json

from .utils_date import describe_period

INTENT_NAME = "top_merchants"
KEYWORDS = [
    "top merchants", "biggest merchants",
    "where did i spend the most", "which merchants",
    "top amazon", "top restaurant merchants",
]


def handle(question: str, intent_name: str, metadata, retriever) -> Dict[str, Any]:
    """Highlight top merchants for a given period."""
    raw = retriever.query(question)
    data = json.loads(raw) if isinstance(raw, str) else raw or {}

    top = data.get("top_merchants", [])
    period_label = describe_period(question)

    if not top:
        answer = f"I couldn't find clear top merchants for {period_label}."
    else:
        list_str = ", ".join(f"{name}: ${amt:,.0f}" for name, amt in top[:5])
        answer = f"Your top merchants in {period_label} were: {list_str}."

    total = data.get("total_spend")
    if total is None:
        total = data.get("total", 0.0)

    details = {
        "top_merchants": top,
        "total_spend": total,
        "matches": data.get("matches", 0),
    }

    chart = None
    if top:
        chart = {
            "type": "bar",
            "labels": [m for m, _ in top],
            "values": [v for _, v in top],
            "title": f"Top Merchants — {period_label}",
        }

    return {
        "intent": INTENT_NAME,
        "answer": answer,
        "details": details,
        "chart": chart,
        "data": data,
    }

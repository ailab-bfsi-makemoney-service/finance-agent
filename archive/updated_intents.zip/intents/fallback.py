from typing import Dict, Any
import json

from .utils_date import describe_period

INTENT_NAME = "fallback"
KEYWORDS = []  # no direct keywords; used when nothing else matches


def handle(question: str, intent_name: str, metadata, retriever) -> Dict[str, Any]:
    """Fallback intent — generic RAG-based summary."""
    raw = retriever.query(question)
    data = json.loads(raw) if isinstance(raw, str) else raw or {}

    total = data.get("total_spend")
    if total is None:
        total = data.get("total", 0.0)

    matches = data.get("matches", 0)
    period_label = describe_period(question)

    answer = (
        f"You spent ${total:,.2f} in {period_label} across "
        f"{matches} transactions."
    )

    details = {
        "matches": matches,
        "total_spend": total,
        "top_merchants": data.get("top_merchants", []),
        "top_categories": data.get("top_categories", []),
        "top_cuisines": data.get("top_cuisines", []),
    }

    chart = None
    if data.get("top_categories"):
        chart = {
            "type": "bar",
            "labels": [c for c, _ in data["top_categories"]],
            "values": [v for _, v in data["top_categories"]],
            "title": "Category Breakdown",
        }

    return {
        "intent": INTENT_NAME,
        "answer": answer,
        "details": details,
        "chart": chart,
        "data": data,
    }

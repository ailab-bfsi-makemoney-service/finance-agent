from typing import Dict, Any
import json

from .utils_date import describe_period

INTENT_NAME = "overall_spend"
KEYWORDS = [
    "overall spend", "overall", "total spend",
    "how much did i spend", "all categories", "everything",
]


def handle(question: str, intent_name: str, metadata, retriever) -> Dict[str, Any]:
    """Overall spend across all categories for a period."""
    # Nudge the retriever to include all categories explicitly
    q2 = question + " including all categories"
    raw = retriever.query(q2)
    data = json.loads(raw) if isinstance(raw, str) else raw or {}

    total = data.get("total_spend")
    if total is None:
        total = data.get("total", 0.0)

    matches = data.get("matches", 0)
    period_label = describe_period(question)

    answer = (
        f"Your overall spend in {period_label} is ${total:,.2f}, "
        f"across {matches} transactions."
    )

    details = {
        "matches": matches,
        "total_spend": total,
        "top_merchants": data.get("top_merchants", []),
        "top_categories": data.get("top_categories", []),
        "top_cuisines": data.get("top_cuisines", []),
    }

    chart = None
    top_categories = data.get("top_categories") or []
    if top_categories:
        chart = {
            "type": "bar",
            "labels": [c for c, _ in top_categories],
            "values": [v for _, v in top_categories],
            "title": "Category Breakdown",
        }

    return {
        "intent": INTENT_NAME,
        "answer": answer,
        "details": details,
        "chart": chart,
        "data": data,
    }

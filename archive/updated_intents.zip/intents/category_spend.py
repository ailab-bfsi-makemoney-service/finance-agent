from typing import Dict, Any
import json
import re

from .utils_date import describe_period

INTENT_NAME = "category_spend"
KEYWORDS = [
    "category", "shopping", "groceries", "grocery", "gas", "fuel",
    "bills", "utilities", "entertainment", "travel", "donations",
    "gifts", "home", "health",
]


def _extract_category_phrase(question: str) -> str:
    q = question.lower()
    m = re.search(r"on ([a-z &]+?) in \d{4}", q)
    if m:
        return m.group(1).title()
    m = re.search(r"on ([a-z &]+?) in", q)
    if m:
        return m.group(1).title()
    m = re.search(r"on ([a-z &]+)$", q)
    if m:
        return m.group(1).title()
    return "that category"


def handle(question: str, intent_name: str, metadata, retriever) -> Dict[str, Any]:
    """Spend focused on a particular category (e.g., Shopping, Utilities)."""
    raw = retriever.query(question)
    data = json.loads(raw) if isinstance(raw, str) else raw or {}

    total = data.get("total_spend")
    if total is None:
        total = data.get("total", 0.0)

    matches = data.get("matches", 0)
    period_label = describe_period(question)
    cat_phrase = _extract_category_phrase(question)

    answer = (
        f"You spent ${total:,.2f} on {cat_phrase} in {period_label}, "
        f"across {matches} transactions."
    )

    details = {
        "matches": matches,
        "total_spend": total,
        "top_merchants": data.get("top_merchants", []),
        "top_categories": data.get("top_categories", []),
        "top_cuisines": data.get("top_cuisines", []),
    }

    chart = None
    top_categories = data.get("top_categories") or []
    if top_categories:
        chart = {
            "type": "bar",
            "labels": [c for c, _ in top_categories],
            "values": [v for _, v in top_categories],
            "title": f"{cat_phrase} vs Other Categories",
        }

    return {
        "intent": INTENT_NAME,
        "answer": answer,
        "details": details,
        "chart": chart,
        "data": data,
    }

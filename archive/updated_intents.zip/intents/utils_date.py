from __future__ import annotations

from datetime import datetime
import re
from typing import Optional, Tuple

MONTHS = {
    "january": 1, "february": 2, "march": 3, "april": 4,
    "may": 5, "june": 6, "july": 7, "august": 8,
    "september": 9, "october": 10, "november": 11, "december": 12,
}


def parse_month_year(text: str) -> Tuple[Optional[int], Optional[int]]:
    q = text.lower()
    month = None
    for name, num in MONTHS.items():
        if name in q:
            month = num
            break

    year = None
    for m in re.finditer(r"\b(20\d{2})\b", q):
        try:
            year = int(m.group(1))
            break
        except ValueError:
            pass

    return month, year


def describe_period(text: str) -> str:
    month, year = parse_month_year(text)
    if month and year:
        month_name = [k for k, v in MONTHS.items() if v == month][0].title()
        return f"{month_name} {year}"
    if month and not year:
        month_name = [k for k, v in MONTHS.items() if v == month][0].title()
        return month_name
    if year and not month:
        return str(year)

    q = text.lower()
    if "ytd" in q or "year to date" in q or "to date" in q:
        return "year to date"

    return "the selected period"

from typing import Dict, Any
import json

from .utils_date import describe_period

INTENT_NAME = "monthly_summary"
KEYWORDS = [
    "summary", "breakdown", "overview",
    "spending summary", "month summary",
]


def handle(question: str, intent_name: str, metadata, retriever) -> Dict[str, Any]:
    """High-level monthly (or period) summary with top categories."""
    raw = retriever.query(question)
    data = json.loads(raw) if isinstance(raw, str) else raw or {}

    total = data.get("total_spend")
    if total is None:
        total = data.get("total", 0.0)

    matches = data.get("matches", 0)
    top_cats = data.get("top_categories", [])
    period_label = describe_period(question)

    parts = [f"In {period_label}, you spent ${total:,.2f} across {matches} transactions."]
    if top_cats:
        top_str = ", ".join(f"{c}: ${v:,.0f}" for c, v in top_cats[:3])
        parts.append(f"Top categories were: {top_str}.")

    answer = " ".join(parts)

    details = {
        "matches": matches,
        "total_spend": total,
        "top_merchants": data.get("top_merchants", []),
        "top_categories": top_cats,
        "top_cuisines": data.get("top_cuisines", []),
    }

    chart = None
    if top_cats:
        chart = {
            "type": "bar",
            "labels": [c for c, _ in top_cats],
            "values": [v for _, v in top_cats],
            "title": f"Spending by Category — {period_label}",
        }

    return {
        "intent": INTENT_NAME,
        "answer": answer,
        "details": details,
        "chart": chart,
        "data": data,
    }

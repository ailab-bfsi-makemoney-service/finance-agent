import os
import json
import numpy as np
import faiss
from sentence_transformers import SentenceTransformer
from collections import defaultdict

class RAGRetriever:
    def __init__(self):
        base_dir = os.path.dirname(os.path.abspath(__file__))
        self.index_path = os.path.join(base_dir, "index", "faiss.index")
        self.meta_path = os.path.join(base_dir, "index", "metadata.json")

        # Load metadata
        with open(self.meta_path, "r") as f:
            self.metadata = json.load(f)

        # Load FAISS index and embedding model
        self.model = SentenceTransformer("all-MiniLM-L6-v2")
        self.index = faiss.read_index(self.index_path)

        # Canonical categories from cc_transaction
        self.category_map = {
            "professional": "Professional Services",
            "shopping": "Shopping",
            "fee": "Fees & Adjustments",
            "education": "Education",
            "personal": "Personal",
            "food": "Food & Drink",
            "drink": "Food & Drink",
            "restaurant": "Food & Drink",
            "automotive": "Automotive",
            "car": "Automotive",
            "entertainment": "Entertainment",
            "movie": "Entertainment",
            "travel": "Travel",
            "flight": "Travel",
            "hotel": "Travel",
            "donation": "Gifts & Donations",
            "gift": "Gifts & Donations",
            "grocery": "Groceries",
            "supermarket": "Groceries",
            "gas": "Gas",
            "fuel": "Gas",
            "home": "Home",
            "bill": "Bills & Utilities",
            "utility": "Bills & Utilities",
            "electric": "Bills & Utilities",
            "water": "Bills & Utilities",
            "health": "Health & Wellness",
            "wellness": "Health & Wellness"
        }

    def detect_category(self, query: str):
        q = query.lower()
        for k, v in self.category_map.items():
            if k in q:
                return v
        return None

    def query(self, question: str, top_k: int = 10):
        """
        Perform semantic similarity search across the FAISS index,
        filtered by normalized spend categories.
        """
        detected_category = self.detect_category(question)

        # Encode query
        q_emb = self.model.encode([question])
        q_emb = np.array(q_emb).astype("float32")

        # Search in FAISS index
        D, I = self.index.search(q_emb, top_k)
        results = [self.metadata[i] for i in I[0] if i < len(self.metadata)]
        if not results:
            return json.dumps({"summary": "No matching transactions found."}, indent=2)

        # Filter results by detected category
        if detected_category:
            results = [
                r for r in results
                if detected_category.lower() in (r.get("category") or "").lower()
            ]

        # Aggregate spending
        total_spend = 0.0
        count = 0
        by_merchant = defaultdict(float)
        categories = defaultdict(float)

        for r in results:
            amt = float(r.get("amount", 0) or 0)
            if amt < 0:
                total_spend += -amt
                count += 1
                merchant = r.get("merchantName") or r.get("description")
                cat = r.get("category") or "Uncategorized"
                by_merchant[merchant] += -amt
                categories[cat] += -amt

        summary = {
            "query": question,
            "detected_category": detected_category or "None",
            "matches": count,
            "total_spend": round(total_spend, 2),
            "top_merchants": sorted(by_merchant.items(), key=lambda x: x[1], reverse=True)[:5],
            "top_categories": sorted(categories.items(), key=lambda x: x[1], reverse=True)[:3],
        }

        return json.dumps(summary, indent=2)


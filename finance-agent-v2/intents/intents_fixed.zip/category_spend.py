import json
INTENT_NAME="category_spend"
KEYWORDS=["category","categories","spend on","shopping","gas","grocery"]
def handle(question, intent_name, metadata, retriever):
    raw=retriever.query(question)
    data = raw if isinstance(raw,dict) else json.loads(raw)
    cats=data.get("top_categories",[])
    answer="Category spend breakdown loaded."
    return {
        "intent":INTENT_NAME,
        "answer":answer,
        "details":{"top_categories":cats,"matches":data.get("matches",0)},
        "chart":None,
        "data":data
    }

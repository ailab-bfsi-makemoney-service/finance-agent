from typing import Dict, Any
INTENT_NAME="restaurant_spend"
KEYWORDS=["restaurant","dining","food","eat"]
def handle(question: str, intent_name: str, metadata, retriever):
    data = retriever.get_restaurant_spend(question)
    total = data.get("total",0.0)
    matches=data.get("matches",0)
    answer=f"You spent ${total:,.2f} at restaurants across {matches} transactions."
    details={
        "matches":matches,
        "top_merchants": data.get("top_restaurants",[]),
        "top_categories": data.get("top_categories",[]),
        "top_cuisines": data.get("top_cuisines",[]),
    }
    return {"intent":INTENT_NAME,"answer":answer,"details":details,"chart":None,"data":data}

import json
INTENT_NAME="top_merchants"
KEYWORDS=["top merchants","best merchants","where did i spend"]
def handle(question, intent_name, metadata, retriever):
    raw=retriever.query(question)
    data= raw if isinstance(raw,dict) else json.loads(raw)
    ans="Top merchants loaded."
    return {"intent":INTENT_NAME,"answer":ans,"details":{},"chart":None,"data":data}

import json
INTENT_NAME="monthly_summary"
KEYWORDS=["month","summary","monthly"]
def handle(question, intent_name, metadata, retriever):
    raw=retriever.query(question)
    data= raw if isinstance(raw,dict) else json.loads(raw)
    total=data.get("total_spend") or data.get("total") or 0.0
    answer=f"Monthly summary: ${total:,.2f}."
    return {"intent":INTENT_NAME,"answer":answer,"details":{},"chart":None,"data":data}
